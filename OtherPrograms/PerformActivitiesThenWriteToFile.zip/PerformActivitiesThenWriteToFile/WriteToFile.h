#ifndef FILE_FUNCTIONS_H
#define FILE_FUNCTIONS_H
   void WriteRandomData(int N, int M, const char *filename);
   void ReadData(const char *filename, int &size, int myArray[]);
#endif
