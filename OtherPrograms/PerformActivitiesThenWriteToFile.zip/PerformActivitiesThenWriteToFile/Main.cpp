
#include "FileFunctions.cpp"
#include "Statistics.cpp"

int* DoubleAndReverse(int* list, int size)
{
    int* modifiedList = new int[2*size];
    for(int i = 0; i < size; i++)
    {
       modifiedList[i] = list[i];
       modifiedList[2*size-i-1] = list[i];
    }  
    return modifiedList;
}

int main()
{
    char name[1000];
    int myArray[1000];
   
    cout<< "Please enter filename: ";
    cin >> name;
   
    int arraysize;
   
    WriteRandomData(5, 100, name);
    ReadData(name, arraysize, myArray);
    double median = getMedian(myArray, arraysize);
    int largest = getLargest(myArray, arraysize);
    int* double_reverse = DoubleAndReverse (myArray, arraysize);
    cout << "Writing file: "<< name << endl;
    cout << "Reading file: "<< name << endl;
    cout << "Array size: "<< arraysize << endl;
    cout << "Doubled and Reversed is [";
    for(int i = 0; i < 2*arraysize-1; i++)
        cout << double_reverse[i] << " ";
    cout << double_reverse[2*arraysize-1] << "]" << endl;  
   
    cout << "Median is: " << median << endl;
    cout << "Largest is: " << largest << endl;
   
    return 0;
}
