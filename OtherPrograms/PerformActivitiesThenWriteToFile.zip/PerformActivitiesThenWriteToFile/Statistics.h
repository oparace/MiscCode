#ifndef STATISTICS_H
#define STATISTICS_H
   double getMedian(const int[], const int);
   int getLargest(const int[], const int);
#endif
