#include <iostream>
#include <fstream>
#include <ctime>
#include "FileFunctions.h"
using namespace std;
void WriteRandomData(int N, int M, const char *filename)
{
    int i;
    int j;
    int l;
    ofstream outputfile;
    outputfile.open(filename);
    srand(time(NULL)); //sync with time
    for(int i = 0; i < N; i++)
    {
       j = rand() % M; //pick a random number from 0 to M
       outputfile << j << " ";
    }
    outputfile.close();
}

//read data and find size
void ReadData(const char *filename, int &size, int myArray[])
{
    size = 0;
    ifstream fin;   //Declares an input file stream
    fin.open(filename);   //Opens the file for streaming.
    while(!fin.eof())   //Keep reading all the data in the file.
        fin >> myArray[size++];  
    size--;  
}
