#include "Statistics.h"


double getMedian(const int myArray[], const int size)
{
    if(size % 2 == 0)   //If even number of elements are there in the list.
        return (myArray[size/2] + myArray[size/2-1]) / 2.0;
    return myArray[size/2];  
}
int getLargest(const int myArray[], const int size)
{
    int large = myArray[0];
    for(int i = 1; i < size; i++)
        if(myArray[i] > large)
            large = myArray[i];
    return large;      
}
